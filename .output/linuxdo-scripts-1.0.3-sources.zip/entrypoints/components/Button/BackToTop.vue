<template>
  <div class="backtotop">
    <div
      class="el-button"
      style="font-size: 18px"
      @click="scrollToTop"
      type="primary"
      title="返回顶部"
    >
    <svg  xmlns="http://www.w3.org/2000/svg"  width="24"  height="24"  viewBox="0 0 24 24"  fill="none"  stroke="currentColor"  stroke-width="2"  stroke-linecap="round"  stroke-linejoin="round"  class="icon icon-tabler icons-tabler-outline icon-tabler-arrow-up-dashed"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M12 5v6m0 3v1.5m0 3v.5" /><path d="M18 11l-6 -6" /><path d="M6 11l6 -6" /></svg>
    </div>
  </div>
</template>

<script>
import $ from "jquery";
export default {
  methods: {
    scrollToTop() {
      window.scrollTo({
        top: 0,
        behavior: 'smooth'
      })
    }
  }
}
</script>
