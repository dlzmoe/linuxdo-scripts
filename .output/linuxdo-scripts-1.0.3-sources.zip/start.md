## 开始使用

**设置开启方法：鼠标移动到页面最左侧会自动弹出。**

![image](https://github.com/user-attachments/assets/1553917a-1b3b-44f4-b624-2ca2a1616e4f)
