# 显示 AI 对话网站

开启后在右下角显示按钮，跳转到 shared chat，需要提前授权。

https://shared.oaifree.com/dashboard
