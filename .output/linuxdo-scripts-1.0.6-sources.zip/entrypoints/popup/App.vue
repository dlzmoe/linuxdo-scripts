<template>
  <h2>欢迎使用 Linxudo Scripts 扩展</h2>
  <h3>鼠标移动到页面最左侧可触发设置！</h3>
</template>

<script>
export default {};
</script>

<style>
body {
  width: 300px;
  text-align: center;
  color: #000000;
}
</style>
