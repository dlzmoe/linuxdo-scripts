# 油猴插件 - 切换论坛主题

以下所有主题不支持切换明亮/黑夜模式，最好以明亮模式使用。

点击链接开始安装。

> 使用此主题不支持进行样式更新。

---

https://raw.githubusercontent.com/dlzmoe/linuxdo-scripts/main/themes/linuxdo-themes-1.user.js

![image](https://github.com/user-attachments/assets/4b4a963e-0256-4e49-90a0-2ead8ca4c51a)

---

https://raw.githubusercontent.com/dlzmoe/linuxdo-scripts/main/themes/linuxdo-themes-2.user.js

![image](https://github.com/user-attachments/assets/3d5b7ab8-514e-485f-bd3b-16c27e4b5288)

---

https://raw.githubusercontent.com/dlzmoe/linuxdo-scripts/main/themes/linuxdo-themes-3.user.js

![image](https://github.com/user-attachments/assets/da4f14cd-f3ed-4bb9-af81-1e955a7c8aad)

---

https://raw.githubusercontent.com/dlzmoe/linuxdo-scripts/main/themes/linuxdo-themes-4.user.js

![image](https://github.com/user-attachments/assets/8efdb813-bd78-4d81-a4fd-2fad66718bc7)

---

https://raw.githubusercontent.com/dlzmoe/linuxdo-scripts/main/themes/linuxdo-themes-5.user.js

![image](https://github.com/user-attachments/assets/a19ab8d2-eb65-48c9-aaba-06bc7603d94f)

---

https://raw.githubusercontent.com/dlzmoe/linuxdo-scripts/main/themes/linuxdo-themes-6.user.js

![image](https://github.com/user-attachments/assets/6a6cb582-a43c-4256-89b2-7e9fcc3afce8)
