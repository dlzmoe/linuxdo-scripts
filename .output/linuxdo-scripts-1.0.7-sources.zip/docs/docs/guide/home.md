# 首页

[https://github.com/dlzmoe/linuxdo-scripts](https://github.com/dlzmoe/linuxdo-scripts)

[https://greasyfork.org/zh-CN/scripts/501827-linuxdo 增强插件](https://greasyfork.org/scripts/501827)

---

linux.do 增强插件。

话题列表显示创建时间，显示楼层数，新标签页打开话题，强制 block（拉黑屏蔽）某人的话题，话题快捷回复（支持自定义），优化签名图显示防止图裂，在话题列表可直接预览详情及评论，功能设置面板导入导出，楼层抽奖，用户自定义标签，只看楼主，自动滚动阅读，支持自定义 css 样式等，中英文混排优化，等级信息查询。

功能持续更新，欢迎提出新想法！

代码已完全开源，如果有误或其他问题请指出！

![Contributor](https://contrib.rocks/image?repo=dlzmoe/linuxdo-scripts)
