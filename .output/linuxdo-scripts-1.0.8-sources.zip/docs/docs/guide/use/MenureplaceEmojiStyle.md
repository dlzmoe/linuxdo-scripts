# 切换论坛表情风格

论坛拥有 twitter / facebook_messenger / google / google_classic / win10 多种风格的表情，可以自定义切换。
