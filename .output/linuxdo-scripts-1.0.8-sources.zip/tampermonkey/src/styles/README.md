# 插件内置论坛主题（此功能基本不更新了，保持现状）

## 1. 科技灰

```css
@import url('https://cdn.jsdelivr.net/gh/dlzmoe/linuxdo-scripts/src/styles/1.css');
```
![](https://i0.hdslb.com/bfs/article/6ba4629fcb986e72ca6def454b3eb07899198664.png)
